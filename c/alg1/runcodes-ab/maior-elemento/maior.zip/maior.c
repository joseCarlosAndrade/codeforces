#include"ab.h"

int _maior(NO * no, int maior) {

    if ( item_get_chave(no->item) > maior) maior = item_get_chave(no->item);

    // descer esquerda
    if(no->esq != NULL) maior = _maior(no->esq, maior);

    // descer direita
    if(no->dir != NULL) maior = _maior(no->dir, maior);

    return maior;

}

int maior(AB *T) {
    return _maior(T->raiz, item_get_chave( T->raiz->item));
}