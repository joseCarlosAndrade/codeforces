#include"avl.h"
// #include"../include/item.h"

#include<assert.h>
#include<stdlib.h>
#include<stdio.h>

NO * rotacao_EE(NO * desb) {
    NO * aux;
    aux = desb->dir;
    desb->dir = aux->esq;
    aux->esq = desb;
    no_atualizar_altura(no);
    no_atualizar_altura(aux);
    return aux;
}

NO * rotacao_DD(NO * desb) {
    NO * aux;
    aux = desb->esq;
    desb->esq = aux->dir;
    aux->dir = desb;
    no_atualizar_altura(no);
    no_atualizar_altura(aux);
    return aux;
}

NO * rotacao_ED(NO * desb) {
    desb->esq = rotacao_EE(desb->esq);
    return rotacao_DD(desb);
}

NO * rotacao_DE(NO * desb) {
    desb->dir = rotacao_DD(desb->dir);
    return rotacao_EE(desb);
}

int atualizar_altura(NO *no){
    if (no == NULL)
        return;
    int esq = 0;
    int dir = 0;

    if (no->esq != NULL)
        esq = no->esq->altura;
    if (no->dir != NULL)
        dir = no->dir->altura;

    no->altura = 1 + max(esq, dir);
}

atualizar_fb(NO *no){
    int e = 0;
    int d = 0;

    if (no->dir != NULL)
        d = no->dir->altura;

    if (no->esq != NULL)
        e = no->esq->altura;

    return e - d;
}

AVL *cria() {
    AVL * a = (AVL*)calloc(1, sizeof(AVL));
    assert(a!=NULL);
    a->raiz=NULL;

    return a;
}

int esta_vazia(AVL *a) {
    assert(a!=NULL);
    return a->raiz == NULL; // verdadeiro se arvore estiver vazia
}

void finaliza(NO *raiz) {
    // assert(raiz!=NULL);

    if (raiz !=NULL) {
        finaliza(raiz->esq);
        finaliza(raiz->dir);
        apagar_item(&(raiz->info));
        free(raiz);
    }
}

void finalizar(AVL*a) {
    assert( a!=NULL);

    finaliza(a->raiz);
    free(a);
}

void imprime(NO *raiz) { // funcoes de impressao do professor
    if(raiz != NULL) {
            printf("%d(", get_valor(raiz->info));
            imprime(raiz->esq);
            printf(",");
            imprime(raiz->dir);
            printf(")");
    } else {
            printf("_");
    }
}

void imprimir(AVL *A) {
    imprime(A->raiz);
    printf("\n");
}

//nao precisa mais dessa funcao, já esta incluida em cada no
int altura_rec(NO *raiz) {// calculo de altura feito pelo codigo do professor
    if(raiz == NULL) 
            return 0;
    
    int alt_esq = 1 + altura_rec(raiz->esq);
    int alt_dir = 1 + altura_rec(raiz->dir);
    
    if(alt_esq > alt_dir)
            return alt_esq;
    
    return alt_dir;
}

int altura(AVL *A) {
    return A->raiz->altura;
}

int busca_recursiva(NO *no, elem chave) {
    if (no == NULL) return 0;

    if (get_valor(no->info) == chave) return 1;

    if (get_valor(no->info) > chave) return busca_recursiva(no->esq, chave);

    return busca_recursiva(no->dir, chave);
}

int busca(AVL *A, elem chave) {
    return busca_recursiva(A->raiz, chave);
}


//eventualmente, simplificar essa funcao com a nova funcao balancear
NO* inserir_rec(NO*raiz, elem chave, int *flag) {
    if (raiz != NULL) {
        if(get_valor((raiz)->info) > chave) {
            raiz->esq = inserir_rec(raiz->esq, chave, flag);

            if(*flag == 1) {
                switch(raiz->   FB) {
                    case -1:
                        raiz->FB = 0;
                        *flag = 0;
                        break;
                    case 0:
                        raiz->FB = 1;
                        *flag = 1;
                        break;
                    case 1:
                        if(raiz->esq->FB > 0) { //sinais iguais
                            raiz = rotacao_DD(raiz);
                            raiz->FB = 0;
                            raiz->dir->FB = 0;
                        } else {
                            raiz = rotacao_ED(raiz);
                            if(raiz->FB == 0) {
                                raiz->esq->FB = 0;
                                raiz->dir->FB = 0;
                            } else if(raiz->FB == -1) {
                                raiz->esq->FB = 1;
                                raiz->dir->FB = 0;
                                raiz->FB = 0;
                            } else { //raiz->fb == 1
                                raiz->esq->FB = 0;
                                raiz->dir->FB = -1;
                                raiz->FB = 0;
                            }
                        }
                        *flag = 0;
                }
            }

        }
        else if (get_valor((raiz)->info) < chave) {
            raiz->dir = inserir_rec((raiz)->dir, chave, flag);

            if(*flag == 1) {
                switch(raiz->FB) {
                    case 1:
                        raiz->FB = 0;
                        *flag = 0;
                        break;
                    case 0:
                        raiz->FB = -1;
                        *flag = 1;
                        break;
                    case -1:
                        if(raiz->dir->FB < 0) { //sinais iguais
                            raiz = rotacao_EE(raiz);
                            raiz->FB = 0;
                            raiz->esq->FB = 0;
                        } else {
                            raiz = rotacao_DE(raiz);
                            if(raiz->FB == 0) {
                                raiz->esq->FB = 0;
                                raiz->dir->FB = 0;
                            } else if(raiz->FB == -1) {
                                raiz->esq->FB = 1;
                                raiz->dir->FB = 0;
                                raiz->FB = 0;
                            } else { //raiz->fb == 1
                                raiz->esq->FB = 0;
                                raiz->dir->FB = -1;
                                raiz->FB = 0;
                            }
                        }
                        *flag = 0;
                }
                        
        }
        }else {
            // printf("Elemento ja existente!\n");
            return 0;
        }
    }
    else {
        raiz = (NO*)calloc(1, sizeof(NO));
        (raiz)->esq = NULL;
        (raiz)->dir = NULL;
        (raiz)->FB = 0;
        (raiz)->altura = 0;
        (raiz)->info = criar_item(chave);
        *flag = 1;
    
    }
    atualizar_altura(raiz);
    return raiz;
    
}

int inserir(AVL * A, elem chave) {
    assert(A!=NULL);
    if (busca(A, chave)) return 0; // chave ja esta inserida
    int flag = 1;   
    A->raiz = inserir_rec(A->raiz, chave, &flag);
    atualizar_altura(A->raiz);
    return 1;

}

int remover(AVL *A, elem chave) {
    assert(A!=NULL);
    A->raiz = remover_recursiva(A->raiz, chave);
    atualizar_altura(A->raiz);
    return 1;    
}
 
NO *balancear(NO *no){
    no->FB = atualizar_fb(no);
    no->esq->FB = atualizar_fb(no->esq);
    no->dir->FB = atualizar_fb(no->dir);

    if (no == NULL)
        return NULL;
    switch (no->FB)
    {
    case -2:
        if (no->dir->FB == -1)
            return rotacao_EE(raiz);
        return rotacao_DE(raiz);

    case 2:
        if (no->esq->FB == 1)
            return rotacao_DD(raiz);
        return rotacao_ED(raiz);
    }
    return no;
}

NO *caso_doisfilhos(NO *no, elem chave){
    if (raiz == NULL)
        return NULL;

    if (no->esq == NULL)
    {
        NO *dir = no->dir;
        *encontrado = no->info;
        no_apagar(&no);
        return dir;
    }

    no->esq = caso_doisfilhos(no->esq, encontrado);
    atualizar_altura(no);
    return no;
}

NO *remover_recursiva(NO *no, elem chave){
    if(no == NULL)
        return 0;

    if(no->info == chave){
        //caso nao tenha filhos ou so tenha um fiho na esquerda
        if (no->dir == NULL)
        {
            NO *no_e = no->esq;
            free(no);
            no == NULL;
            return no_e;
        }

        //caso so tenha um filho na direita
        if (no->esq == NULL)
        {
            NO *no_d = no->dir;
            free(no);
            no == NULL;
            return no_d;
        }

        //caso tenha dois filhos

        elem menor_direita;
        no->dir = no_pop_rec(no->dir, &menor_direita);
        no->info = menor_direita;
        atualizar_altura(no);
        return balancear(no);
    }

    if(no->info < chave){
        no->dir = remover_recursiva(no->dir, chave);
    }
    else{
        no->esq = remover_recursiva(no->esq, chave);
    }
    atualizar_altura(no);
    return balancear(no);
}

