#include"avl.h"
#include<stdio.h>

int avl_test() {
    AVL * avl= cria();

    inserir(avl, 10);
    inserir(avl, 5);
    inserir(avl, 1);
    inserir(avl, 12);
    inserir(avl, 9);
    inserir(avl, 13);
    inserir(avl, 14);
    inserir(avl, 15);
    inserir(avl, 16);

    imprimir(avl);

    printf("\n");
    if (busca(avl, 10)) {
        printf("Elemento 10 encontrado.\n");
    }
    if (busca(avl, 20)) {
        printf("Elemento 10 encontrado.\n");
    }
    finalizar(avl);
}