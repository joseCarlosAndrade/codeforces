#include"set.h"
#include<stdio.h>

int main() {
    SET * set = set_criar();
    SET * setB = set_criar();
    set_inserir(set, 10);
    set_inserir(set, 9);
    set_inserir(set, 11);
    set_inserir(set, 13);
    set_inserir(set, 1);
    set_inserir(set, 23);

    set_inserir(setB, 11);
    set_inserir(setB, 12);
    set_inserir(setB, 9);
    set_inserir(setB, 1);
    set_inserir(setB, 45);


    set_imprimir(set);
    printf("removendo 45 do primeiro:\n");
    set_remover(set, 45);
    set_imprimir(set);
    set_imprimir(setB);

    if(set_pertence(set, 10)) {
        printf("O elemento 10 pertence no conjunto\n");
    }

    if(set_pertence(set, 20)) {
        printf("O elemento 20 pertence no conjunto\n");
    }

    SET*u = set_uniao(set, setB);
    set_imprimir(u);

    SET*i = set_interseccao(set, setB);
    set_imprimir(i);

    set_apagar(&set);
    set_apagar(&setB);
    set_apagar(&u);
    set_apagar(&i);

}